(function() {
    $('.docs-book-wrapper:has(#dns-server-driver-support-matrix)').addClass('wide')
})();
