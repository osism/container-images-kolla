.. _central:

*******
Central
*******

.. _rpcapi:

Central RPC API
===============
.. automodule:: designate.central.rpcapi
     :members:
     :undoc-members:
     :show-inheritance:

Central Service
===============

.. automodule:: designate.central.service
     :members:
     :undoc-members:
     :show-inheritance:
