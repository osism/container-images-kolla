.. _api:

***
API
***

.. _api-middleware:

API Middleware
===============

.. automodule:: designate.api.middleware
    :members:
    :undoc-members:
    :show-inheritance:

.. _api-service:

API Service
===========

.. automodule:: designate.api.service
    :members:
    :undoc-members:
    :show-inheritance:

