.. _sink:

****
Sink
****

.. _sink-service:

Sink Service
============

.. automodule:: designate.sink.service
    :members:
    :undoc-members:
    :show-inheritance:


