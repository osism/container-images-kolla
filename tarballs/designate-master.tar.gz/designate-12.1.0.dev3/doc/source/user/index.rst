==========
User guide
==========

In this section, you will find documentation relevant for using
Designate.

Contents:

.. toctree::
   :maxdepth: 2

   rest
   manage-ptr-records
   secondary-zones
