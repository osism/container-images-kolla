==========================
Sample configuration files
==========================

Configuration files can alter how designate behaves at runtime and by default
are located in ``/etc/designate/``. Links to sample configuration files can be
found below:

.. toctree::

   policy-yaml.rst
   config.rst
