===========
policy.yaml
===========

Use the ``policy.yaml`` file to define additional access controls that apply to
the DNS service:

.. literalinclude:: ../../_static/designate.policy.yaml.sample
    :language: yaml
