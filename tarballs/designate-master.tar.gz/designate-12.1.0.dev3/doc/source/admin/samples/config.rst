==============
designate.conf
==============

.. only:: html

   .. literalinclude:: ../../_static/designate.conf.sample
      :language: ini

.. only:: latex

   Please refer to the online version of this documentation for a full
   config file example.
