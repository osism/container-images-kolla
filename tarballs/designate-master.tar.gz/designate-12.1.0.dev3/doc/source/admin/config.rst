====================
Config Documentation
====================

The following is an overview of all available configuration in Designate. For a
sample configuration file, refer to :doc:`samples/config`.

.. show-options::
   :config-file: etc/designate/designate-config-generator.conf
