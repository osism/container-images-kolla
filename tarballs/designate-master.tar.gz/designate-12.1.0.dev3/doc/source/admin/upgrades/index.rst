========
Upgrades
========

In this section, you will find documentation relevant for upgrading Designate.

.. note:: The :ref:`designate-status upgrade check <designate-status-upgrade-check>`
          command can be used to verify a deployment before starting services
          with new code.

Contents:

.. toctree::
   :maxdepth: 2

   kilo
   mitaka
   newton
   ocata
