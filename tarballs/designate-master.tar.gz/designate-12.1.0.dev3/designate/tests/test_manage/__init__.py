from designate.tests import TestCase


class DesignateManageTestCase(TestCase):
    pass
